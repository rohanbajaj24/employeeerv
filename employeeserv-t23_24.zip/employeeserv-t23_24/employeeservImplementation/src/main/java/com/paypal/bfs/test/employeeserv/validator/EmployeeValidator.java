package com.paypal.bfs.test.employeeserv.validator;

import com.paypal.bfs.test.employeeserv.exceptions.InvalidInputException;
import com.paypal.bfs.test.employeeserv.jpa.EmployeeRepository;
import com.paypal.bfs.test.employeeserv.jpa.model.EmployeesEntity;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.util.Optional;
import java.util.function.Consumer;

import static com.paypal.bfs.test.employeeserv.constants.ErrorMessages.ERR_MSG_ENTITY_ALREADY_EXISTING;

/**
 * @author Rohan.Bajaj on 13/07/21
 */
@Service
public class EmployeeValidator extends BaseValidator {

    private final EmployeeRepository employeeRepository;

    EmployeeValidator(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public void validate(Object entity, Errors errors) {
        super.validate(entity, errors);
        if (!errors.hasErrors() && entity instanceof EmployeesEntity) {
            EmployeesEntity employee = (EmployeesEntity) entity;
            super.validate(employee.getAddressEntity(), errors);
            checkDuplicateRecord(employee, errors);
        }
    }

    @Override
    protected Class<?> getClassType() {
        return EmployeesEntity.class;
    }

    @Override
    protected Consumer<Errors> errorHandler() {
        return e -> {
            throw new InvalidInputException("Failed with error count " + e.getErrorCount());
        };
    }

    public void checkDuplicateRecord(EmployeesEntity employee, Errors errors) {
        if (!errors.hasErrors()) {
            Optional<EmployeesEntity> employeesEntity = employeeRepository.findByFirstNameAndLastName(employee.getFirstName(), employee.getLastName());
            if (employeesEntity.isPresent()) {
                throw new InvalidInputException(ERR_MSG_ENTITY_ALREADY_EXISTING + " with first name :" + employee.getFirstName() + " last name :" + employee.getLastName());
            }
        }
    }

}
