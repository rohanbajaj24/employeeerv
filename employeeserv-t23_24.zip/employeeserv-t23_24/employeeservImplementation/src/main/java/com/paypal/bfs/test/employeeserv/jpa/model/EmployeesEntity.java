package com.paypal.bfs.test.employeeserv.jpa.model;

import lombok.Data;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToOne;
import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import java.util.Date;

@Data
@Entity(name = "employees")
public class EmployeesEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE)
    private Integer id;

    @NotNull(message = "{employee.firstName.isNull.message}")
    @NotEmpty(message = "{employee.firstName.NotBlank.message}")
    @Column(name = "first_name")
    private String firstName;

    @NotNull(message = "{employee.lastName.NotBlank.message}")
    @NotEmpty(message = "{employee.lastName.isNull.message}")
    @Column(name = "last_name")
    private String lastName;
    
    @Past(message = "{employee.dateOfBirth.past.message}")
    @Column(name = "date_of_birth")
    private Date dateOfBirth;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id", referencedColumnName = "id")
    private AddressEntity addressEntity;
}
