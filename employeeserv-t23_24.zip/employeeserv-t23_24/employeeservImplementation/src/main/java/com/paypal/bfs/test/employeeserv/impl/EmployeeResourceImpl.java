package com.paypal.bfs.test.employeeserv.impl;

import com.paypal.bfs.test.employeeserv.api.EmployeeResource;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.constants.ErrorMessages;
import com.paypal.bfs.test.employeeserv.exceptions.InvalidInputException;
import com.paypal.bfs.test.employeeserv.jpa.EmployeeRepository;
import com.paypal.bfs.test.employeeserv.jpa.model.EmployeesEntity;
import com.paypal.bfs.test.employeeserv.mapper.EmployeeMapper;
import com.paypal.bfs.test.employeeserv.validator.EmployeeValidator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Optional;

/**
 * Implementation class for employee resource.
 */
@RestController
public class EmployeeResourceImpl implements EmployeeResource {

    private final EmployeeValidator employeeValidator;
    private final EmployeeRepository employeeRepository;

    public EmployeeResourceImpl(EmployeeValidator employeeValidator,
                                EmployeeRepository employeeRepository) {
        this.employeeValidator = employeeValidator;
        this.employeeRepository = employeeRepository;
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        if (employeeValidator != null)
            binder.setValidator(employeeValidator);
    }

    @Override
    public ResponseEntity<Employee> employeeGetById(String id) {
        Optional<EmployeesEntity> employeesEntityOptional = employeeRepository.findById(Integer.valueOf(id));
        if (employeesEntityOptional.isPresent()) {
            Employee employee = EmployeeMapper.mapToEmployee(employeesEntityOptional.get());
            return new ResponseEntity<>(employee, HttpStatus.OK);
        } else {
            throw new InvalidInputException(ErrorMessages.ERR_MSG_ENTITY_NOT_FOUND + id);
        }
    }

    @Override
    public ResponseEntity<Employee> createEmployee(@Valid Employee employee) {
        EmployeesEntity employeesEntity = EmployeeMapper.mapToEmployeeEntity(employee);
        employeesEntity = employeeRepository.save(employeesEntity);
        return employeeGetById(String.valueOf(employeesEntity.getId()));
    }

}
