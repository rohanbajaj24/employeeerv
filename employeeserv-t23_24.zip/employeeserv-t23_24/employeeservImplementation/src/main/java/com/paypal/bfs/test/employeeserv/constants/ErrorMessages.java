package com.paypal.bfs.test.employeeserv.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author Rohan.Bajaj on 13/07/21
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ErrorMessages {
    public static final String DATE_FORMAT_STRING = "dd-mm-YYYY";
    public static final String ERR_MSG_TARGET_NULL = "Target object must not be null";
    public static final String ERR_MSG_ENTITY_NULL = "The object to be validated must not be null.";
    public static final String ERR_MSG_ENTITY_ALREADY_EXISTING = "Entity already exists";
    public static final String ERR_MSG_INVALID_DATE_PATTERN = "Invalid Date pattern. Date format should be DD-MM-YYYY";
    public static final String ERR_MSG_ENTITY_NOT_FOUND = "Entity not found with Id ";
}
