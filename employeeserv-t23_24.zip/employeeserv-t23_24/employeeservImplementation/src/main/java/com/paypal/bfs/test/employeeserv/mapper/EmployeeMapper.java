package com.paypal.bfs.test.employeeserv.mapper;

import com.paypal.bfs.test.employeeserv.api.model.Address;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.jpa.model.AddressEntity;
import com.paypal.bfs.test.employeeserv.jpa.model.EmployeesEntity;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import static com.paypal.bfs.test.employeeserv.util.ValidationUtil.CONVERT_DATE_STRING;
import static com.paypal.bfs.test.employeeserv.util.ValidationUtil.VALIDATE_DATE_FORMAT;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EmployeeMapper {

    public static Employee mapToEmployee(EmployeesEntity employeesEntity) {
        Employee employee = new Employee();
        employee.setId(employeesEntity.getId());
        employee.setFirstName(employeesEntity.getFirstName());
        employee.setLastName(employeesEntity.getLastName());
        employee.setDateOfBirth(CONVERT_DATE_STRING.apply(employeesEntity.getDateOfBirth()));
        employee.setAddress(mapToAddress(employeesEntity.getAddressEntity()));
        return employee;
    }

    private static Address mapToAddress(AddressEntity addressEntity) {
        Address address = new Address();
        address.setLine1(addressEntity.getLine1());
        address.setLine2(addressEntity.getLine2());
        address.setCity(addressEntity.getCity());
        address.setState(addressEntity.getState());
        address.setCountry(addressEntity.getCountry());
        address.setZipcode(addressEntity.getZipcode());
        return address;
    }

    public static EmployeesEntity mapToEmployeeEntity(Employee employee) {
        EmployeesEntity employeesEntity = new EmployeesEntity();
        employeesEntity.setFirstName(employee.getFirstName());
        employeesEntity.setLastName(employee.getLastName());
        employeesEntity.setDateOfBirth(VALIDATE_DATE_FORMAT.apply(employee.getDateOfBirth()));
        employeesEntity.setAddressEntity(mapToAddressEntity(employee.getAddress()));
        return employeesEntity;
    }

    private static AddressEntity mapToAddressEntity(Address address) {
        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setCity(address.getCity());
        addressEntity.setCountry(address.getCountry());
        addressEntity.setState(address.getState());
        addressEntity.setZipcode(address.getZipcode());
        addressEntity.setLine1(address.getLine1());
        addressEntity.setLine2(address.getLine2());
        return addressEntity;
    }
}
