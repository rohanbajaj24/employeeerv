package com.paypal.bfs.test.employeeserv.validator;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.function.Consumer;

import static com.paypal.bfs.test.employeeserv.util.ValidationUtil.validateRequiredFields;

/**
 * @author Rohan.Bajaj on 13/07/21
 */
@Service
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public abstract class BaseValidator implements Validator {

    @Override
    public void validate(Object entity, Errors errors) {
        validateRequiredFields(entity, errors);
        if(errors.hasErrors()){
            errorHandler().accept(errors);
        }
    }
    
    @Override
    public boolean supports(Class<?> aClass) {
        return this.getClassType().isAssignableFrom(aClass);
    }
    
    protected abstract Class<?> getClassType();
    
    protected abstract Consumer<Errors> errorHandler();
}
