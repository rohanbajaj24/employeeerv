package com.paypal.bfs.test.employeeserv.exceptions;

/**
 * @author Rohan.Bajaj on 13/07/21
 */
public class InvalidInputException extends RuntimeException{

    public InvalidInputException(String message) {
        super(message);
    }
}
