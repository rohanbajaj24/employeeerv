package com.paypal.bfs.test.employeeserv.util;

import com.paypal.bfs.test.employeeserv.exceptions.InvalidInputException;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.validation.Errors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import java.util.function.Function;

import static com.paypal.bfs.test.employeeserv.constants.ErrorMessages.DATE_FORMAT_STRING;
import static com.paypal.bfs.test.employeeserv.constants.ErrorMessages.ERR_MSG_INVALID_DATE_PATTERN;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ValidationUtil {

    private static final Validator constraintValidator;

    static {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        constraintValidator = factory.getValidator();
    }

    public static void validateRequiredFields(Object entity, Errors errors) {
        validateConstraintViolation(entity, errors);
    }

    private static void validateConstraintViolation(Object entity, Errors errors) {
        Set<ConstraintViolation<Object>> constraintViolations = constraintValidator.validate(entity);
        if (constraintViolations != null) {
            constraintViolations.forEach(constraintViolation -> errors.reject(constraintViolation.getPropertyPath().toString(), constraintViolation.getMessage()));
        }
    }

    public static final Function<String, Date> VALIDATE_DATE_FORMAT = date -> {
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_STRING);
        dateFormat.setLenient(false);
        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
            throw new InvalidInputException(ERR_MSG_INVALID_DATE_PATTERN);
        }
    };

    public static final Function<Date, String> CONVERT_DATE_STRING = date -> {
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_STRING);
        dateFormat.setLenient(false);
        return dateFormat.format(date);
    };
}
