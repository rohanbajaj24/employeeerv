package com.paypal.bfs.test.employeeserv.jpa.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@Entity(name = "address")
public class AddressEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "{employee.address.addressLine1.isNull.message}")
    @NotEmpty(message = "{employee.address.addressLine1.NotBlank.message}")
    @Column(name = "line1")
    private String line1;
    
    @Column(name = "line2")
    private String line2;

    @NotNull(message = "{employee.address.city.isNull.message}")
    @NotEmpty(message = "{employee.address.city.NotBlank.message}")
    @Column(name = "city")
    private String city;

    @NotNull(message = "{employee.address.state.isNull.message}")
    @NotEmpty(message = "{employee.address.state.NotBlank.message}")
    @Column(name = "state")
    private String state;

    @NotNull(message = "{employee.address.country.isNull.message}")
    @NotEmpty(message = "{employee.address.country.NotBlank.message}")
    @Column
    private String country;

    @NotNull(message = "{employee.address.zipcode.isNull.message}")
    @NotEmpty(message = "{employee.address.zipcode.NotBlank.message}")
    @Column(name = "zipcode")
    private String zipcode;
}
