package com.paypal.bfs.test.employeeserv.validator;

import com.paypal.bfs.test.employeeserv.api.model.Address;
import com.paypal.bfs.test.employeeserv.api.model.Employee;
import com.paypal.bfs.test.employeeserv.constants.ErrorMessages;
import com.paypal.bfs.test.employeeserv.exceptions.InvalidInputException;
import com.paypal.bfs.test.employeeserv.jpa.model.EmployeesEntity;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;

/**
 * @author Rohan.Bajaj on 13/07/21
 */
@RunWith(SpringRunner.class)
public class EmployeeValidatorTest {

    @InjectMocks
    private EmployeeValidator employeeValidator;
    @Rule
    public ExpectedException exception = ExpectedException.none();


    @Test
    public void testValidateWithNull() {
        exception.expect(IllegalArgumentException.class);
        exception.expectMessage(ErrorMessages.ERR_MSG_TARGET_NULL);
        EmployeesEntity employee = null;
        Errors errors = new BindException(employee, "Employee Object");
        employeeValidator.validate(employee, errors);
    }

    @Test
    public void testValidateWithAddressNull() {
        exception.expect(IllegalArgumentException.class);
        exception.expectMessage(ErrorMessages.ERR_MSG_ENTITY_NULL);
        EmployeesEntity employee = new EmployeesEntity();
        employee.setFirstName("firstName");
        employee.setLastName("lastName");
        employee.setAddressEntity(null);
        Errors errors = new BindException(employee, "Employee Object");
        employeeValidator.validate(employee, errors);
    }

    @Test
    public void testValidateWithConstrainViolation() {
        exception.expect(InvalidInputException.class);
        exception.expectMessage("Failed with error count 2");
        EmployeesEntity employee = new EmployeesEntity();
        employee.setFirstName("firstName");
        Errors errors = new BindException(employee, "Employee Object");
        employeeValidator.validate(employee, errors);
    }

    @Test
    public void testValidateWithSuccess() {
        Address address = getAddress();
        Employee employee = new Employee();
        employee.setFirstName("firstName");
        employee.setLastName("lastName");
        employee.setDateOfBirth("02-02-1990");
        employee.setAddress(address);
        Errors errors = new BindException(employee, "Employee Object");
        employeeValidator.validate(employee, errors);
    }

    private Address getAddress() {
        Address address = new Address();
        address.setLine1("addressLine1");
        address.setCity("city");
        address.setState("state");
        address.setCountry("country");
        address.setZipcode("123456");
        return address;
    }
}